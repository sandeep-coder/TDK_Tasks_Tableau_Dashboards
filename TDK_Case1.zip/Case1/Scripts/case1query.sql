USE sandeep

---SELECT the sample data from campaign

SELECT TOP 5 * FROM campaign

---SELECT the distinct country from the above dataframe

SELECT DISTINCT Country
FROM campaign

---SELECT the distinct product_category from the above dataframe

SELECT DISTINCT Product_category
FROM campaign

---SELECT the distinct Channel from the above dataframe

SELECT DISTINCT Channel
FROM campaign
---Understand the product category wise revenue

SELECT country,channel,product_category,SUM(Revenue) as revenue
FROM campaign
WHERE product_category = 'Car-Marine'
GROUP BY country,Product_category,channel
HAVING SUM(Revenue) = 0
ORDER BY country,revenue desc

---Extract the max and minimum revenue by product category wise

SELECT country,channel,product_category,Revenue
FROM campaign
WHERE Visits IN(
SELECT MIN(Visits)
FROM campaign)

SELECT * FROM campaign

---Sample Extracts outputs starts here

---Show Country and Product category and channel wise total revenue

SELECT country,Product_category,channel,sum(Revenue) as Total_revenue,sum(Visits) as Total_visits
FROM campaign
GROUP BY country,Product_category,channel
ORDER BY Country,Product_category,Total_revenue desc,Total_visits desc

---Export the Top 5 Popular channels by enagagement

SELECT * 
FROM campaign

SELECT Country,Channel,sum(Visits) as total_visits
FROM campaign
GROUP BY Country,Channel
ORDER BY total_visits desc

SELECT  Country,Channel,SUM(visits)
OVER (PARTITION BY Country ORDER BY visits desc) as visits
FROM campaign 
ORDER BY Country,Channel




CREATE VIEW higher_channels as
(SELECT Country,Channel,SUM(Visits) as total_visits,DENSE_RANK() OVER (PARTITION BY Country ORDER BY SUM(Visits) desc) ranked
FROM campaign
GROUP BY Country,Channel)

SELECT Country,Channel FROM 
higher_channels
WHERE ranked IN (1,2,3,4,5)


---Extract the same above requirement for revenue by channels as well

CREATE VIEW higher_channels_revenue as
(SELECT Country,Channel,SUM(Revenue) as total_revenue,DENSE_RANK() OVER (PARTITION BY Country ORDER BY SUM(Revenue) desc) ranked
FROM campaign
GROUP BY Country,Channel)

SELECT Country,Channel FROM 
higher_channels_revenue
WHERE ranked IN (1,2,3,4,5)

---Find the channels that generate zero revenue but higher channel rate

SELECT Country,Channel,SUM(Revenue) as total_revenue,SUM(Visits) as visits
FROM campaign
WHERE Country = 'RU'
GROUP BY Country,Channel
HAVING SUM(Revenue) = 0
ORDER BY SUM(Visits) desc

---Find the channels that generate zero visiting rate  but higher revenue rate

SELECT Country,Channel,SUM(Revenue) as total_revenue,SUM(Visits) as visits
FROM campaign
GROUP BY Country,Channel
ORDER BY SUM(Visits) asc


---Find the channel and product wise revenue -to- visit rate
CREATE VIEW  aggregated as
SELECT Country,Channel,Product_category,SUM(Revenue) as revenue,SUM(Visits) as visitor
FROM campaign
GROUP BY Country,Channel,Product_category

SELECT * FROM aggregated


SELECT Country,Channel,Product_category,round((revenue/visitor),2) as revenue_per_visitor
FROM aggregated

---Work on the dates

SELECT DISTINCT SUBSTRING('- ',WE FROM 
campaign

SELECT CHARINDEX('- ',Week)
FROM campaign



SELECT *,CASE WHEN SUBSTRING(WEEK,CHARINDEX('- ',Week)+1,LEN(Week)- CHARINDEX('- ',Week)+1) = ' 13-Sep-2020'
THEN 'Week1'
ELSE 'Week2'
END as Week_name
FROM campaign

---Validate your data hypothesis
---An insight has been observed warranties not present in the countries BE and RU

SELECT Country,COUNT(DISTINCT Channel) as channel,Count(DISTINCT Product_category) as prod_cat
FROM campaign
GROUP BY Country

SELECT DISTINCT product_category FROM campaign
WHERE product_category NOT IN
(SELECT DISTINCT product_category
FROM campaign WHERE Country IN ('BE','RU'))

---Understand the size of Warranties business in the other countries

SELECT Channel,Country,SUM(Revenue) as revenue
FROM campaign
WHERE product_category = 'Warranties'
GROUP BY Channel,Country
HAVING SUM(Revenue) > 0
ORDER BY revenue desc

---Warranties segment business is little by revenue and also zero in some countries

SELECT Channel,Country,product_category,SUM(Revenue) as revenue
FROM campaign
WHERE product_category = 'Warranties'
GROUP BY Country,product_category,Channel
HAVING SUM(Revenue) = 0

---Understand the business segment (Product_categories) that have zero contribution to the business country wise
---Channel wise because Audio may have greater than 0 sales thorough other channels not specific to other channels

CREATE VIEW Weak_channels as
SELECT Country,Product_category,channel,SUM(revenue) as total_revenue,SUm(visits) as total_visits
FROM campaign
GROUP BY Country,Product_category,channel
HAVING SUM(revenue) = 0


SELECT * FROM Weak_channels

SELECT * FROM
(SELECT Country,channel,
COUNT(Product_category) OVER (PARTITION BY Country,Product_category) as count_of_products
FROM Weak_channels)
as t
ORDER BY count_of_products desc

---Countries that have higher weak channels in terms of revenue which is zero


SELECT Country,Channel,SUM(Revenue) as revenue
FROM campaign
GROUP BY Country,Channel
HAVING SUM(Revenue) = 0

SELECT DISTINCT Country,Channel,COUNT(Product_category) 
OVER (PARTITION BY Country,Channel ) as #_weakchannels
FROM campaign
WHERE Revenue = 0



---Classifying the channels on Revenue
SELECT * FROM campaign

--110-270 Bronze
--170-275 Silver
--275> Gold

DROP VIEW cleaned
CREATE VIEW  cleaned
AS
SELECT campaign.*,directory.Country_name,CASE WHEN SUBSTRING(WEEK,CHARINDEX('- ',Week)+1,LEN(Week)- CHARINDEX('- ',Week)+1) = ' 13-Sep-2020'
THEN 'Week1'
ELSE 'Week2'
END as Week_name,
CASE WHEN Revenue > 0 and Revenue <= 14302 THEN 'Followers'
WHEN Revenue > 14302 and Revenue <= 28604 THEN 'Challengers'
WHEN Revenue = 0 THEN 'Last Movers'
ELSE 'Leaders' END as Sales_Performance_Category
FROM campaign
LEFT JOIN directory
ON campaign.country = directory.Country

SELECT TOP 5 * FROM cleaned

---Find the visitor and revenue total by country wise

SELECT Country,SUM(revenue),sum(visits)
FROM cleaned
GROUP BY Country

SELECT * FROM directory
SELECT * FROM cleaned

UPDATE VIEW cleaned as
SELECT cleaned.*,directory.Country_name FROM
cleaned LEFT JOIN directory
ON cleaned.country = directory.Country

----7th Jan
SELECT TOP 5* FROM cleaned

SELECT COUNT(*) FROM cleaned
SELECT DISTINCT(COUNT(*)) FROM cleaned

--DECLARING KPI'S
---REVENUE KPI
SELECT ROUND(AVG(REVENUE),2) AS AVG_REVENUE
FROM cleaned

---VISITS KPI
SELECT ROUND(AVG(Visits),2) AS AVG_VISITS
FROM cleaned

---POPULAR CHANNEL ON revenue front
SELECT WEEK_NAME,Channel,SUM(REVENUE) AS TOTAL_REVENUE
FROM cleaned
GROUP BY Channel,Week_name


CREATE VIEW  RANKED_CHANNEL AS
SELECT WEEK_NAME,Channel,SUM(REVENUE) AS TOTAL_REVENUE,RANK() OVER(PARTITION BY WEEK_NAME ORDER BY SUM(REVENUE) DESC)
AS RANKED
FROM cleaned
GROUP BY WEEK_NAME,CHANNEL

SELECT WEEK_NAME,CHANNEL,TOTAL_REVENUE FROM RANKED_CHANNEL
WHERE RANKED = 1

----Natural search has the higher revenue rate

---Popular channel on visits front
DROP VIEW RANKED_CHANNEL_VISITS
CREATE VIEW  RANKED_CHANNEL_VISITS AS
SELECT WEEK_NAME,Channel,SUM(Visits) AS TOTAL_VISITS,RANK() OVER(PARTITION BY WEEK_NAME ORDER BY SUM(Visits) DESC)
AS RANKED
FROM cleaned
GROUP BY WEEK_NAME,CHANNEL

SELECT WEEK_NAME,CHANNEL,TOTAL_VISITS FROM RANKED_CHANNEL_VISITS
WHERE RANKED = 1

---IT is evident that Natural search has higher revenue


DROP VIEW RANKED_PRODUCT_REVENUE
---Popular product on revenue front
CREATE VIEW  RANKED_PRODUCT_REVENUE AS
SELECT WEEK_NAME,Product_category,SUM(Revenue) AS TOTAL_REVENUE,RANK() OVER(PARTITION BY WEEK_NAME ORDER BY SUM(Revenue) DESC)
AS RANKED
FROM cleaned
GROUP BY WEEK_NAME,Product_category

SELECT WEEK_NAME,Product_category,TOTAL_REVENUE FROM RANKED_PRODUCT_REVENUE
WHERE RANKED = 1

---Popular product on visits front
CREATE VIEW  RANKED_PRODUCT_VISITS AS
SELECT WEEK_NAME,Product_category,SUM(Visits) AS TOTAL_VISITS,RANK() OVER(PARTITION BY WEEK_NAME ORDER BY SUM(Visits) DESC)
AS RANKED
FROM cleaned
GROUP BY WEEK_NAME,Product_category

SELECT WEEK_NAME,Product_category,TOTAL_VISITS FROM RANKED_PRODUCT_VISITS
WHERE RANKED = 1

----TELEVISION HAS HIGHER SALES BUT CAMERA HAS THE HIGHER VISIT RATE
----SOME ISSUE TO PONDER OVER
---RP visit

SELECT SUM(REVENUE)/SUM(visits)
FROM cleaned

SELECT SUM(VISITS) AS SUM_OF_VISITS
FROM cleaned

