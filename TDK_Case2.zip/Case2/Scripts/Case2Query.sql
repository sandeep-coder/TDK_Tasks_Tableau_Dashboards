---Select the database

USE SANDEEP

SELECT TOP 5* FROM activity
SELECT TOP 5* FROM contact
SELECT DISTINCT(organization) FROM contact

SELECT NAME FROM contact 
WHERE contactid IN (
SELECT contactid
FROM activity
GROUP BY contactid
HAVING COUNT(contactid) >1
)


SELECT * FROM activity WHERE referrerurl IS NOT NULL

--SHOW THE UNIQUE REFERRALURL

SELECT referrerurl
FROM activity
GROUP BY referrerurl


SELECT referrerurl
FROM activity
WHERE referrerurl LIKE '%/SEARCH/%'
GROUP BY referrerurl


SELECT url
FROM activity
WHERE referrerurl LIKE '%product.tdk.com/ja/search/%'
GROUP BY url

SELECT DISTINCT *
FROM activity

UPDATE activity SET referrerurl = REPLACE(referrerurl, 'https://','')

UPDATE activity SET referrerurl = REPLACE(referrerurl, 'https://product.tdk.com%','')

DELETE FROM activity where referrerurl LIKE '%www%'

UPDATE activity SET url = REPLACE(url, 'https://product.tdk.com%','')



---Leads By products

SELECT DISTINCT url
FROM activity
WHERE url LIKE '%/products/%' AND url LIKE 'https://%' AND url NOT LIKE '%products/index.html%'


---Leads by catalog

SELECT DISTINCT url
FROM activity
WHERE url LIKE '%/catalog/datasheets%' AND url LIKE 'https://%' 

---Leads by Tech library

SELECT DISTINCT url
FROM activity
WHERE url LIKE '%/techlibrary/%' AND url LIKE 'https://%'  
---Leads by Tech library solutionguide

SELECT DISTINCT url
FROM activity
WHERE url LIKE '%/techlibrary/solutionguide/%' AND url LIKE 'https://%'  AND url LIKE '%.html'

---Leads by Tech library application note
SELECT DISTINCT url
FROM activity
WHERE url LIKE '%/techlibrary/applicationnote/%' AND url LIKE 'https://%'  AND url LIKE '%.html'


---documents eduactional
SELECT DISTINCT url
FROM activity
WHERE url LIKE '%/documents/%' AND url LIKE 'https://%'

--CONTACT CUSTOMER PROBLEMS

SELECT DISTINCT url
FROM activity
WHERE url LIKE '%/contact/%' AND url NOT LIKE '%contact/index.html%'

--technical support
SELECT DISTINCT url
FROM activity
WHERE url LIKE '%/technicalsupport/%' AND url NOT LIKE '%contact/index.html%'

---tech-mag
SELECT DISTINCT url
FROM activity
WHERE url LIKE '%/tech-mag/%' 

--Removing the clutter
SELECT * FROM activity 
WHERE url IN
(SELECT DISTINCT url
FROM activity
WHERE url LIKE '%/search/%' AND url LIKE 'https://%' AND url NOT LIKE 'products/%'
UNION
SELECT DISTINCT url
FROM activity
WHERE url LIKE '%/products/%' AND url LIKE 'https://%' 
UNION
SELECT DISTINCT url
FROM activity
WHERE url LIKE '%/catalog/datasheets%' AND url LIKE 'https://%' AND url	NOT LIKE '%/30/DB/%'
UNION
SELECT *
FROM activity
WHERE url LIKE '%/techlibrary/productoverview%' AND url LIKE 'https://%' 
UNION 
SELECT DISTINCT url
FROM activity
WHERE url LIKE '%/techlibrary/solutionguide/%' AND url LIKE 'https://%'  AND url LIKE '%.html'
UNION
SELECT *
FROM activity
WHERE url LIKE '%/techlibrary/applicationnote/%' AND url LIKE 'https://%'  AND url LIKE '%.html'
UNION
SELECT *
FROM activity
WHERE url LIKE '%/documents/%' AND url LIKE 'https://%'
UNION
SELECT *
FROM activity
WHERE url LIKE '%/contact/%' AND url NOT LIKE '%contact/index.html%'
UNION
SELECT DISTINCT url
FROM activity
WHERE url LIKE '%/technicalsupport/%' AND url NOT LIKE '%contact/index.html%'
UNION
SELECT DISTINCT url
FROM activity
WHERE url LIKE '%/tech-mag/%' 
)


----Cleaning activity begins
---By products

SELECT*
FROM activity
WHERE url LIKE '%/products/%' AND url LIKE 'https://%' 

----Upload a cleaned dataset now
----No duplicate records found
SELECT COUNT(*)
FROM activity

SELECT Web_touchpoint
FROM processed_new_case2
GROUP BY Web_touchpoint

SELECT count(*)
FROM processed_new_case2 - SELECT count(*)
FROM processed_new_case2
WHERE Web_touchpoint NOT IN ('ja','zh','en')

SELECT *  FROM
processed_new_case2

SELECT MAX(activitydate)
FROM processed_new_case2

SELECT YEAR(activitydate) as year_,web_touchpoint,COUNT(Web_touchpoint) as countoftouchpoints
FROM processed_new_case2
WHERE Web_touchpoint NOT IN ('ja','zh','en')
GROUP BY  YEAR(activitydate) ,Web_touchpoint

SELECT YEAR(activitydate) as year_,web_touchpoint,COUNT(activitydate) OVER
(PARTITION BY web_touchpoint) as total_count
FROM processed_new_case2
WHERE Web_touchpoint NOT IN ('ja','zh','en')
GROUP BY  YEAR(activitydate) ,web_touchpoint

SELECT DATEDIFF(day,activitydate,linkedtocontactdate)
FROM processed_new_case2


CREATE VIEW  avg_contact_linkdate
AS
SELECT contactid,DATEDIFF(DAY,linked_date,visited_date) as days
FROM
(SELECT  contactid,MIN(activitydate) as visited_date,MIN(linkedtocontactdate) AS linked_date
FROM processed_new_case2
GROUP BY contactid) AS T1
WHERE contactid = 2587

SELECT avg(days) as avg_link_to_visit_date
FROM avg_contact_linkdate

--Companies list

SELECT COUNT(DISTINCT organization)
FROM contact

SELECT *
FROM processed_new_case2

SELECT  TOP 5 * FROM processed_new_case2